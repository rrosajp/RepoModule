class Rect(object):
    def __init__(self, l, w):
        super(Rect, self).__init__()
        self.length = l
        self.width = w
my_rect=Rect(5, 10)
print('TEST SUCEEDED!')

